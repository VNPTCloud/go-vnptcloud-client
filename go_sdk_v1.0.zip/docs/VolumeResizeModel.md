# VolumeResizeModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**VolumeId** | **int32** |  | [default to null]
**NewSize** | **int32** |  | [default to null]
**Iops** | **int32** |  | [default to null]
**Description** | **string** |  | [optional] [default to null]
**ProjectId** | **int32** |  | [default to null]
**VolumeName** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

