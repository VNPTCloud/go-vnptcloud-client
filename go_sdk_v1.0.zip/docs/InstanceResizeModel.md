# InstanceResizeModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstanceId** | **int32** | Id máy ảo sẽ điều chỉnh | [optional] [default to null]
**Cpu** | **int32** | Cpu tăng thêm | [optional] [default to null]
**Ram** | **int32** | Ram tăng thêm | [optional] [default to null]
**VolumeSize** | **int32** | Dung lượng ổ root tăng thêmn | [optional] [default to null]
**GpuTypeId** | **int32** | Id loại Gpu tăng thêm | [optional] [default to null]
**GpuCount** | **int32** | Số lượng Gpu tăng thêm | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

