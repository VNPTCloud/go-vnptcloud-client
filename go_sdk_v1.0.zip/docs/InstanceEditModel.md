# InstanceEditModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InstanceId** | **int32** | Id máy ảo sẽ điều chỉnh | [optional] [default to null]
**NewImageId** | **int32** | Id hệ điều hành mới | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

