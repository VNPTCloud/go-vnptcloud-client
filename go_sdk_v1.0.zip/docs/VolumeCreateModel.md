# VolumeCreateModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProjectId** | **int32** | Id dự án | [default to null]
**VolumeName** | **string** | Tên máy ảo | [default to null]
**VolumeType** | **string** |  | [default to null]
**VolumeSize** | **int32** |  | [default to null]
**Description** | **string** |  | [optional] [default to null]
**Iops** | **int32** |  | [optional] [default to null]
**CreateFromSnapshotId** | **int32** |  | [optional] [default to null]
**InstanceToAttachId** | **int32** |  | [optional] [default to null]
**IsMultiAttach** | **bool** |  | [optional] [default to null]
**IsEncryption** | **bool** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

